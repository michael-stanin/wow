
if GetLocale() ~= "ptBR" then return end
local _, tbl = ...
local L = tbl.L

--L["BasicComboPoints is a numerical display of your current combo points, with extras such as a font and color chooser."] = "BasicComboPoints is a numerical display of your current combo points, with extras such as a font and color chooser."

--L["Lock the points frame in its current location."] = "Lock the points frame in its current location."

--L["Font"] = "Font"
--L["Apply the font you wish to use for your Combo Points."] = "Apply the font you wish to use for your Combo Points."

--L["Apply the color you wish to use for your Combo Points."] = "Apply the color you wish to use for your Combo Points."

--L["Apply the %s you wish to use for Combo Point %d."] = "Apply the %s you wish to use for Combo Point %d."

--L["Apply the size you wish to use for your Combo Points."] = "Apply the size you wish to use for your Combo Points."

--L["Apply a shadow to your text."] = "Apply a shadow to your text."

--L["Outline"] = "Outline"
--L["Apply a outline to your text."] = "Apply a outline to your text."
--L["Thick Outline"] = "Thick Outline"

