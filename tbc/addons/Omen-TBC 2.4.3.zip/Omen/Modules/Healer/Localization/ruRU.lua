﻿--  Translation by Eritnull (StingerSoft aka Шептун)
local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("Omen_Healer", "ruRU")
if not L then return end

L["Healer Mode"] = "Режим Лекаря"
L["Column Spacing"] = "Расстояние между столбцами"

L["Data source"] = "Источник данных"
L["Get tanks from..."] = "Получить танков из.."
L["oRA2 Main Tanks"] = "Танки из oRA2"
L["Blizzard Main Tanks"] = "Танки из Blizzard"
L["Healer Mode\n|cffffffffShows an overview of tank target threat\nTank targets come from oRA2 or the Blizzard tank settings.|r"] = "Режим Лекаря\n|cffffffffПоказывает общую угрозу с целей танков\nТанки и их цели,берутся из настроек oRA2 или Blizzard.\nТ.е. если в Blizzard'ских или oRA2 настройках выставлены танки,то этот режим будет работоспособным.|r"
