-- English, the default

MAPCOORDS_VERSION 	= "0.4";

-- Chat notifications
MAPCOORDS_HWorld	= "MapCoords > Now hiding all coords on worldmap";
MAPCOORDS_SWorld	= "MapCoords > Now showing all coords on worldmap";
MAPCOORDS_HCursor	= "MapCoords > Now hiding cursor coords on worldmap";
MAPCOORDS_SCursor	= "MapCoords > Now showing cursor coords on worldmap";
MAPCOORDS_HWPlayer	= "MapCoords > Now hiding player coords on worldmap";
MAPCOORDS_SWPlayer	= "MapCoords > Now showing player coords on worldmap";
MAPCOORDS_HPortrait	= "MapCoords > Now hiding all portrait coords";
MAPCOORDS_SPortrait	= "MapCoords > Now showing all portrait coords";
MAPCOORDS_HPlayer	= "MapCoords > Now hiding player portrait coords";
MAPCOORDS_SPlayer	= "MapCoords > Now showing player portrait coords";
MAPCOORDS_HAParty	= "MapCoords > Now hiding all party members portrait coords";
MAPCOORDS_SAParty	= "MapCoords > Now showing all party members portrait coords";
MAPCOORDS_HParty1	= "MapCoords > Now hiding your first party member portrait coords";
MAPCOORDS_SParty1	= "MapCoords > Now showing your first party member portrait coords";
MAPCOORDS_HParty2	= "MapCoords > Now hiding your second party member portrait coords";
MAPCOORDS_SParty2	= "MapCoords > Now showing your second party member portrait coords";
MAPCOORDS_HParty3	= "MapCoords > Now hiding your third party member portrait coords";
MAPCOORDS_SParty3	= "MapCoords > Now showing your third party member portrait coords";
MAPCOORDS_HParty4	= "MapCoords > Now hiding your fourth party member portrait coords";
MAPCOORDS_SParty4	= "MapCoords > Now showing your fourth party member portrait coords";

-- Slash information
MAPCOORDS_SLASH1	= "Slash Commands:";
MAPCOORDS_SLASH2	= "-- Worldmap Coords --";
MAPCOORDS_SLASH3	= "-- Portrait Coords --";

MAPCOORDS_WMON	= "/mc [worldmap|w] -ON- Toggles display of coords on the worldmap";
MAPCOORDS_WMOFF	= "/mc [worldmap|w] -OFF- Toggles display of coords on the worldmap";
MAPCOORDS_WMCON	= "/mc [worldmap cursor|wc|w c] -ON- Toggles display of cursor coords on the worldmap";
MAPCOORDS_WMCOFF	= "/mc [worldmap cursor|wc|w c] -OFF- Toggles display of cursor coords on the worldmap";
MAPCOORDS_WMPON	= "/mc [worldmap player|wp|w p] -ON- Toggles display of player coords on the worldmap";
MAPCOORDS_WMPOFF	= "/mc [worldmap player|wp|w p] -OFF- Toggles display of player coords on the worldmap";
MAPCOORDS_APON	= "/mc [portrait|p] -ON- Toggles display of all portrait coords";
MAPCOORDS_APOFF	= "/mc [portrait|p] -OFF- Toggles display of all portrait coords";
MAPCOORDS_YPON	= "/mc [player] -ON- Toggles display of your portrait coords";
MAPCOORDS_YPOFF	= "/mc [player] -OFF- Toggles display of your portrait coords";
MAPCOORDS_APMON	= "/mc [party] -ON- Toggles display of your all your party members portrait coords";
MAPCOORDS_APOFF	= "/mc [party] -OFF- Toggles display of your all your party members portrait coords";
MAPCOORDS_P1ON	= "/mc [party1|party 1|p 1|p1] -ON- Toggles display of your first party member portrait coords";
MAPCOORDS_P1OFF	= "/mc [party1|party 1|p 1|p1] -OFF- Toggles display of your first party member portrait coords";
MAPCOORDS_P2ON	= "/mc [party2|party 2|p 2|p2] -ON- Toggles display of your second party member portrait coords";
MAPCOORDS_P2OFF	= "/mc [party2|party 2|p 2|p2] -OFF- Toggles display of your second party member portrait coords";
MAPCOORDS_P3ON	= "/mc [party3|party 3|p 3|p3] -ON- Toggles display of your third party member portrait coords";
MAPCOORDS_P3OFF	= "/mc [party3|party 3|p 3|p3] -OFF- Toggles display of your third party member portrait coords";
MAPCOORDS_P4ON	= "/mc [party4|party 4|p 4|p4] -ON- Toggles display of your fourth party member portrait coords";
MAPCOORDS_P4OFF	= "/mc [party4|party 4|p 4|p4] -OFF- Toggles display of your fourth party member portrait coords";
MAPCOORDS_ABOUT	= "/mc [about|a] -- Shows some about info";

-- German
if (GetLocale() == "deDE") then

-- Chat notifications
MAPCOORDS_HWorld	= "MapCoords > Alle Worldmap Koordinaten werden ausgeblendet";
MAPCOORDS_SWorld	= "MapCoords > Alle Worldmap Koordinaten werden eingeblendet";
MAPCOORDS_HCursor	= "MapCoords > Cursor-Koordinaten auf der Worldmap werden ausgeblendet";
MAPCOORDS_SCursor	= "MapCoords > Cursor-Koordinaten auf der Worldmap werden eingeblendet";
MAPCOORDS_HWPlayer	= "MapCoords > Player-Koordinaten auf der Worldmap werden ausgeblendet";
MAPCOORDS_SWPlayer	= "MapCoords > Player-Koordinaten auf der Worldmap werden eingeblendet";
MAPCOORDS_HPortrait	= "MapCoords > Alle Portrait-Koordinaten werden ausgeblendet";
MAPCOORDS_SPortrait	= "MapCoords > Alle Portrait-Koordinaten werden eingeblendet";
MAPCOORDS_HPlayer	= "MapCoords > Player-Koordinaten werden ausgeblendet";
MAPCOORDS_SPlayer	= "MapCoords > Player-Koordinaten werden eingeblendet";
MAPCOORDS_HAParty	= "MapCoords > Alle Gruppen-Portrait-Koordinaten werden ausgeblendet";
MAPCOORDS_SAParty	= "MapCoords > Alle Gruppen-Portrait-Koordinaten werden eingeblendet";
MAPCOORDS_HParty1	= "MapCoords > Ersten Gruppen-Portrait-Koordinaten werden ausgeblendet";
MAPCOORDS_SParty1	= "MapCoords > Ersten Gruppen-Portrait-Koordinaten werden eingeblendet";
MAPCOORDS_HParty2	= "MapCoords > Zweiten Gruppen-Portrait-Koordinaten werden ausgeblendet";
MAPCOORDS_SParty2	= "MapCoords > Zweiten Gruppen-Portrait-Koordinaten werden eingeblendet";
MAPCOORDS_HParty3	= "MapCoords > Dritten Gruppen-Portrait-Koordinaten werden ausgeblendet";
MAPCOORDS_SParty3	= "MapCoords > Dritten Gruppen-Portrait-Koordinaten werden eingeblendet";
MAPCOORDS_HParty4	= "MapCoords > Vierten Gruppen-Portrait-Koordinaten werden ausgeblendet";
MAPCOORDS_SParty4	= "MapCoords > Vierten Gruppen-Portrait-Koordinaten werden eingeblendet";

-- Slash information
MAPCOORDS_SLASH1	= "Slash Commands:";
MAPCOORDS_SLASH2	= "-- Worldmap Coords --";
MAPCOORDS_SLASH3	= "-- Portrait Coords --";

MAPCOORDS_WMON	= "/mc [worldmap|w] -ON- Blendet die Koordinaten in der Worldmap ein";
MAPCOORDS_WMOFF	= "/mc [worldmap|w] -OFF- Blendet die Koordinaten in der Worldmap aus";
MAPCOORDS_WMCON	= "/mc [worldmap cursor|wc|w c] -ON- Blendet die Koordinaten des Maus-Zeigers in der Worldmap ein";
MAPCOORDS_WMCOFF	= "/mc [worldmap cursor|wc|w c] -OFF- Blendet die Koordinaten des Maus-Zeigers in der Worldmap aus";
MAPCOORDS_WMPON	= "/mc [worldmap player|wp|w p] -ON- Blendet die Player-Koordinaten in der Worldmap ein";
MAPCOORDS_WMPOFF	= "/mc [worldmap player|wp|w p] -OFF- Blendet die Player-Koordinaten in der Worldmap aus";
MAPCOORDS_APON	= "/mc [portrait|p] -ON- Blendet alle Portrait-Koordinaten ein";
MAPCOORDS_APOFF	= "/mc [portrait|p] -OFF- Blendet alle Portrait-Koordinaten aus";
MAPCOORDS_YPON	= "/mc [player] -ON- Blendet alle Player-Koordinaten ein";
MAPCOORDS_YPOFF	= "/mc [player] -OFF- Blendet alle Player-Koordinaten aus";
MAPCOORDS_APMON	= "/mc [party] -ON- Blendet alle Gruppen-Portrait-Koordinaten ein";
MAPCOORDS_APOFF	= "/mc [party] -OFF- Blendet alle Gruppen-Portrait-Koordinaten aus";
MAPCOORDS_P1ON	= "/mc [party1|party 1|p 1|p1] -ON- Blendet die ersten Gruppen-Portrait-Koordinaten ein";
MAPCOORDS_P1OFF	= "/mc [party1|party 1|p 1|p1] -OFF- Blendet die ersten Gruppen-Portrait-Koordinaten aus";
MAPCOORDS_P2ON	= "/mc [party2|party 2|p 2|p2] -ON- Blendet die zweiten Gruppen-Portrait-Koordinaten ein";
MAPCOORDS_P2OFF	= "/mc [party2|party 2|p 2|p2] -OFF- Blendet die zweiten Gruppen-Portrait-Koordinaten aus";
MAPCOORDS_P3ON	= "/mc [party3|party 3|p 3|p3] -ON- Blendet die dritten Gruppen-Portrait-Koordinaten ein";
MAPCOORDS_P3OFF	= "/mc [party3|party 3|p 3|p3] -OFF- Blendet die dritten Gruppen-Portrait-Koordinaten aus";
MAPCOORDS_P4ON	= "/mc [party4|party 4|p 4|p4] -ON- Blendet die vierten Gruppen-Portrait-Koordinaten ein";
MAPCOORDS_P4OFF	= "/mc [party4|party 4|p 4|p4] -OFF- Blendet die vierten Gruppen-Portrait-Koordinaten aus";
MAPCOORDS_ABOUT	= "/mc [about|a] -- Zeigt die Info zu diesem Addon";

end