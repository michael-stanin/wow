--[[

	EnergyWatch-specific RuneFrame

--]]

function EnergyWatchUI.CreateRuneFrame()
	-- Create a new frame to serve as parent frame for the runes
	local runeParentFrame = CreateFrame("Frame", "EWRuneFrame", EnergyWatchBar);
	-- Attach WoW's "RuneFrameMixin" to it, it will do all the work
	Mixin(runeParentFrame, RuneFrameMixin);
	-- Set up position
	runeParentFrame:SetFrameStrata("LOW");
	runeParentFrame:SetToplevel(true);
	runeParentFrame:SetSize(130, 24);	-- Values from WoW's Interface\FrameXML\RuneFrame.xml
	runeParentFrame:SetPoint("TOP", EnergyWatchBar, "BOTTOM", 4, 4);
	-- WoW's "RuneFrameMixin" wants its runes stored in Runes[] array
	runeParentFrame.Runes = {};
	
	for iRune = 1, 6 do
		-- Create a new frame for a rune
		local runeFrameName = "EWRuneButtonIndividual" .. iRune;
		local runeFrame = CreateFrame("Button", runeFrameName, runeParentFrame, "RuneButtonIndividualTemplate");
		-- WoW's "RuneFrameMixin" wants its runes stored in Runes[] array
		runeParentFrame.Runes[iRune] = runeFrame;
		
		-- Set up position
		if 1 == iRune then
			runeFrame:SetPoint("LEFT", runeParentFrame, "LEFT", -6, 0);	-- Values from WoW's Interface\FrameXML\RuneFrame.xml
		else
			local prevRuneFrame = runeParentFrame.Runes[iRune - 1];
			runeFrame:SetPoint("LEFT", prevRuneFrame, "RIGHT", -3, 0);	-- Values from WoW's Interface\FrameXML\RuneFrame.xml
		end
	end
	
	runeParentFrame:OnLoad();
end
