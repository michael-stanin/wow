Usage:
/ncb
/ncb help
/ncb lock
/ncb unlock
/ncb scale x.xx (0.5 - 2.0)
/ncb showcombat
/ncb showempty
/ncb colorall
/ncb color1
/ncb color2
/ncb color3
/ncb color4
/ncb color5

In Skins directory you can find alternative textures for points.
Just replace NCBPoint.tga in root directory.
