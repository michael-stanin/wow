NCOMBOBAR_FADE_IN = 0.3;
NCOMBOBAR_FADE_OUT = 0.5;
NCOMBOBAR_HIGHLIGHT_FADE_IN = 0.4;
NCOMBOBAR_SHINE_FADE_IN = 0.3;
NCOMBOBAR_SHINE_FADE_OUT = 0.4;
NCOMBOBAR_FRAME_LAST_NUM_POINTS = 0;
local player = " "
local locked = 1;
local combat = 0;
function NComboBarPointsFrame_OnLoad()
for i=1, 5 do
getglobal("NComboBarPoint"..i.."Shine"):SetAlpha(0);
getglobal("NComboBarPoint"..i.."Highlight"):SetAlpha(0);
end
NComboBar:EnableMouse(false);
this:RegisterForDrag("LeftButton");
SLASH_NUGCBF1= "/ncb";
SLASH_NUGCBF2 = "/nugiecombobar";
SlashCmdList["NUGCBF"] = NComboBarPointsFrame_SlashCmd;

local _,class = UnitClass("player");
if (class == "ROGUE" or class == "DRUID") then
	local realmName = GetCVar("realmName");
	local playerName = UnitName("player");
	player = realmName.."|"..playerName;
	this:RegisterEvent("VARIABLES_LOADED");
	this:RegisterEvent("PLAYER_TARGET_CHANGED");
	this:RegisterEvent("PLAYER_COMBO_POINTS");
--~ 	UIErrorsFrame:UnregisterEvent("UI_ERROR_MESSAGE");
-- 	ComboFrame:UnregisterEvent("PLAYER_TARGET_CHANGED");
-- 	ComboFrame:UnregisterEvent("PLAYER_COMBO_POINTS");
	-- init alpha
end
end

function NComboBarPointsFrame_OnEvent()
	if (event == "VARIABLES_LOADED") then
		if (not CBFConfig) then CBFConfig = {}; end
		if (not CBFConfig[player]) then
			CBFConfig[player] = {};
			CBFConfig[player]["showempty"] = 0;
			CBFConfig[player]["scale"] = 1;
		end
		if (CBFConfig[player]["showempty"] == 1) then
			NComboBar:Show();
			UIFrameFadeIn(NComboBar, NCOMBOBAR_FADE_IN);
			
		end
		if (CBFConfig[player]["scale"] == nil) then
			CBFConfig[player]["scale"] = 1;
		end;
        if (CBFConfig[player]["r1"] == nil) then
            local r = 1;
            local g = 0.2;
            local b = 0.2;
            for i=1, 5 do
                CBFConfig[player]["r"..i] = r;
                CBFConfig[player]["g"..i] = g;
                CBFConfig[player]["b"..i] = b;
            end
		end;
        if (CBFConfig[player]["showcombat"] == nil) then
            CBFConfig[player]["showcombat"] = 0;
        end
        if (CBFConfig[player]["showcombat"] == 1) then
            this:RegisterEvent("PLAYER_REGEN_ENABLED")
            this:RegisterEvent("PLAYER_REGEN_DISABLED")
        end
		NComboBar:SetScale(CBFConfig[player]["scale"]);
		for i=1, 5 do
            getglobal("NComboBarPoint"..i.."Highlight"):SetVertexColor(CBFConfig[player]["r"..i],CBFConfig[player]["g"..i],CBFConfig[player]["b"..i]);
        end
	else
    if (event == "PLAYER_REGEN_DISABLED") then
        combat = 1;
    elseif (event == "PLAYER_REGEN_ENABLED") then
        combat = 0;
    end
	local comboPoints = GetComboPoints();
	local comboPoint, comboPointHighlight, fadeInfo;
	if ( comboPoints > 0 - CBFConfig[player]["showempty"] + (locked - 1)  - combat) then
		if ( not NComboBar:IsVisible() ) then
			NComboBar:Show();
			UIFrameFadeIn(NComboBar, NCOMBOBAR_FADE_IN);
		end
		
		for i=1, MAX_COMBO_POINTS do
			comboPointHighlight = getglobal("NComboBarPoint"..i.."Highlight");
			comboPointShine = getglobal("NComboBarPoint"..i.."Shine");
			if ( i <= comboPoints ) then
				if ( i > NCOMBOBAR_FRAME_LAST_NUM_POINTS ) then
					-- Fade in the highlight and set a function that triggers when it is done fading
					fadeInfo = {};
					fadeInfo.mode = "IN";
					fadeInfo.timeToFade = NCOMBOBAR_HIGHLIGHT_FADE_IN;
					fadeInfo.finishedFunc = NComboBarPointShineFadeIn;
					fadeInfo.finishedArg1 = comboPointShine;
					UIFrameFade(comboPointHighlight, fadeInfo);
				end
			else
				comboPointHighlight:SetAlpha(0);
				comboPointShine:SetAlpha(0);
			end
		end
	else
		NComboBarPoint1Highlight:SetAlpha(0);
		NComboBarPoint1Shine:SetAlpha(0);
		NComboBar:Hide();
	end
	NCOMBOBAR_FRAME_LAST_NUM_POINTS = comboPoints;
	end
end

function NComboBarPointShineFadeIn(frame)
	-- Fade in the shine and then fade it out with the NComboBarPointShineFadeOut function
	local fadeInfo = {};
	fadeInfo.mode = "IN";
	fadeInfo.timeToFade = NCOMBOBAR_SHINE_FADE_IN;
	fadeInfo.finishedFunc = NComboBarPointShineFadeOut;
	fadeInfo.finishedArg1 = frame:GetName();
	UIFrameFade(frame, fadeInfo);
end

--hack since a frame can't have a reference to itself in it
function NComboBarPointShineFadeOut(frameName)
	UIFrameFadeOut(getglobal(frameName), NCOMBOBAR_SHINE_FADE_OUT);
end

function NCB_Color(point, r, g, b)
if ( not r ) then
    r, g, b = ColorPickerFrame:GetColorRGB();
end
if (point < 6) then
    CBFConfig[player]["r"..point] = r;
    CBFConfig[player]["g"..point] = g;
    CBFConfig[player]["b"..point] = b;
    getglobal("NComboBarPoint"..point.."Highlight"):SetVertexColor(r,g,b);
else
    for i=1, 5 do
        CBFConfig[player]["r"..i] = r;
        CBFConfig[player]["g"..i] = g;
        CBFConfig[player]["b"..i] = b;
        getglobal("NComboBarPoint"..i.."Highlight"):SetVertexColor(r,g,b);
    end
end
end

function NComboBarPointsFrame_SlashCmd(msg)
	if (msg == "help" or msg == "") then 
		DEFAULT_CHAT_FRAME:AddMessage("Usage:")
		DEFAULT_CHAT_FRAME:AddMessage("/ncb lock")
		DEFAULT_CHAT_FRAME:AddMessage("/ncb unlock")
		DEFAULT_CHAT_FRAME:AddMessage("/ncb scale (0.5 - 2.0)")
        DEFAULT_CHAT_FRAME:AddMessage("/ncb showcombat")
		DEFAULT_CHAT_FRAME:AddMessage("/ncb showempty - background visibility when 0 points")
        DEFAULT_CHAT_FRAME:AddMessage("/ncb colorall - color for all points")
        DEFAULT_CHAT_FRAME:AddMessage("/ncb color1 - color config for first point")
        DEFAULT_CHAT_FRAME:AddMessage("...")
		DEFAULT_CHAT_FRAME:AddMessage("/ncb color5")
    elseif (msg == "colorall") then
		local oldr = CBFConfig[player]["r1"];
        local oldg = CBFConfig[player]["g1"];
        local oldb = CBFConfig[player]["b1"];
        ColorPickerFrame:Show();
        ColorPickerFrame.hasOpacity = false;
        ColorPickerFrame.func = function() NCB_Color(6) end;
        ColorPickerFrame.cancelFunc = function() NCB_Color(6, oldr, oldg, oldb) end;
        ColorPickerFrame:SetColorRGB(oldr, oldg, oldb);
    elseif (msg == "color1") then
        local oldr = CBFConfig[player]["r1"];
        local oldg = CBFConfig[player]["g1"];
        local oldb = CBFConfig[player]["b1"];
        ColorPickerFrame:Show();
        ColorPickerFrame.hasOpacity = false;
        ColorPickerFrame.func = function() NCB_Color(1) end;
        ColorPickerFrame.cancelFunc = function() NCB_Color(1, oldr, oldg, oldb) end;
        ColorPickerFrame:SetColorRGB(oldr, oldg, oldb);
    elseif (msg == "color2") then
        local oldr = CBFConfig[player]["r2"];
        local oldg = CBFConfig[player]["g2"];
        local oldb = CBFConfig[player]["b2"];
        ColorPickerFrame:Show();
        ColorPickerFrame.hasOpacity = false;
        ColorPickerFrame.func = function() NCB_Color(2) end;
        ColorPickerFrame.cancelFunc = function() NCB_Color(2, oldr, oldg, oldb) end;
        ColorPickerFrame:SetColorRGB(oldr, oldg, oldb);
    elseif (msg == "color3") then
        local oldr = CBFConfig[player]["r3"];
        local oldg = CBFConfig[player]["g3"];
        local oldb = CBFConfig[player]["b3"];
        ColorPickerFrame:Show();
        ColorPickerFrame.hasOpacity = false;
        ColorPickerFrame.func = function() NCB_Color(3) end;
        ColorPickerFrame.cancelFunc = function() NCB_Color(3, oldr, oldg, oldb) end;
        ColorPickerFrame:SetColorRGB(oldr, oldg, oldb);
    elseif (msg == "color4") then
        local oldr = CBFConfig[player]["r4"];
        local oldg = CBFConfig[player]["g4"];
        local oldb = CBFConfig[player]["b4"];
        ColorPickerFrame:Show();
        ColorPickerFrame.hasOpacity = false;
        ColorPickerFrame.func = function() NCB_Color(4) end;
        ColorPickerFrame.cancelFunc = function() NCB_Color(4, oldr, oldg, oldb) end;
        ColorPickerFrame:SetColorRGB(oldr, oldg, oldb);
    elseif (msg == "color5") then
        local oldr = CBFConfig[player]["r5"];
        local oldg = CBFConfig[player]["g5"];
        local oldb = CBFConfig[player]["b5"];
        ColorPickerFrame:Show();
        ColorPickerFrame.hasOpacity = false;
        ColorPickerFrame.func = function() NCB_Color(5) end;
        ColorPickerFrame.cancelFunc = function() NCB_Color(5, oldr, oldg, oldb) end;
        ColorPickerFrame:SetColorRGB(oldr, oldg, oldb);
	elseif (msg == "unlock") then
        locked = 0;
        NComboBar:EnableMouse(true);
        if ( not NComboBar:IsVisible() ) then
			NComboBar:Show();
			UIFrameFadeIn(NComboBar, NCOMBOBAR_FADE_IN);
		end
        DEFAULT_CHAT_FRAME:AddMessage("ncb unlocked");
	elseif (msg == "lock") then
		locked = 1;
        NComboBar:EnableMouse(false);
        if (GetComboPoints() == 0) then NComboBar:Hide() end;
        DEFAULT_CHAT_FRAME:AddMessage("ncb locked");
	elseif (string.sub(msg, 1, 5) == "scale" ) then
		local scale = tonumber(string.sub(msg, 7));
		if( scale <= 2.0 and scale >= 0.5 ) then
			NComboBar:SetScale(scale);
			CBFConfig[player]["scale"]=scale;
		end
	elseif (msg == "showempty") then
		if (CBFConfig[player]["showempty"] == 1) then
			CBFConfig[player]["showempty"] = 0;
			DEFAULT_CHAT_FRAME:AddMessage("ncb show empty disabled");
			if (GetComboPoints() == 0) then
				NComboBar:Hide();
			end
		else
			CBFConfig[player]["showempty"] = 1;
			DEFAULT_CHAT_FRAME:AddMessage("ncb show empty enabled");
			if (GetComboPoints() == 0) then
				NComboBar:Show();
				UIFrameFadeIn(NComboBar, NCOMBOBAR_FADE_IN);
			end
		end
    elseif (msg == "showcombat") then
		if (CBFConfig[player]["showcombat"] == 1) then
			CBFConfig[player]["showcombat"] = 0;
            combat = 0;
            this:UnregisterEvent("PLAYER_REGEN_ENABLED")
            this:UnregisterEvent("PLAYER_REGEN_DISABLED")
			DEFAULT_CHAT_FRAME:AddMessage("ncb show combat disabled");
		else
			CBFConfig[player]["showcombat"] = 1;
            this:RegisterEvent("PLAYER_REGEN_ENABLED")
            this:RegisterEvent("PLAYER_REGEN_DISABLED")
			DEFAULT_CHAT_FRAME:AddMessage("ncb show combat enabled");
		end
	end
end

function NComboBarPointsFrame_Drag()
	if (locked == 0) then
		this:StartMoving();
	end
end
