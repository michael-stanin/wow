Assassin_UpdateInterval = 0.1;


SLASH_AssassinTimer1 = "/assassintimer"
SlashCmdList["AssassinTimer"] = function(msg, editFrame)
	if msg == "reset" then
		AssassinFrame:ClearAllPoints();
		AssassinFrame:SetPoint("BOTTOMLEFT");
	else
		print("Type '/assassintimer reset' to reset the frame.");
	end
end

function Assassin_OnLoad()
	local playerClass, englishClass = UnitClass("player");
	if (englishClass == "ROGUE") then
		AssassinFrame:RegisterEvent("UNIT_COMBO_POINTS");
		AssassinFrame:RegisterEvent("VARIABLES_LOADED");
		AssassinFrame:RegisterEvent("PLAYER_TARGET_CHANGED");
	else
		AssassinFrame:Hide();
	end
end

function Assassin_OnEvent(self, event, ...)
	if(event == "VARIABLES_LOADED") then
		AssassinFrame:RegisterForDrag("LeftButton");
		ComboText:SetText("0/5");
		ComboBar:SetMinMaxValues(0,5);
		ComboBar:SetValue(0);
		SliceText:SetText("0");
		SliceBar:SetMinMaxValues(0,0);
		SliceBar:SetValue(0);
		EnergyText:SetText("0");
		EnergyBar:SetMinMaxValues(0,0);
		EnergyBar:SetValue(0);
		EnvBar:SetMinMaxValues(0,0);
		EnvBar:SetValue(0);
		RuptureText:SetText("0");
		RuptureBar:SetMinMaxValues(0,0);
		RuptureBar:SetValue(0);
		AssassinFrame:Show();
		AssassinFrame.TimeSinceLastUpdate = 0;
	end		
	if(event == "UNIT_COMBO_POINTS") then
		Assassin_showCombo(GetComboPoints("player"));
	end
	if(event == "PLAYER_TARGET_CHANGED") then

		Assassin_showCombo(GetComboPoints("player"));
	end
end

function Assassin_OnUpdate(AssassinFrame, elapsed)
	if (AssassinFrame.TimeSinceLastUpdate) then
		AssassinFrame.TimeSinceLastUpdate = AssassinFrame.TimeSinceLastUpdate + elapsed;
		if (AssassinFrame.TimeSinceLastUpdate > Assassin_UpdateInterval) then
			Assassin_doSnD();
			Assassin_doNrg();
			Assassin_doRup();
			Assassin_doEnv();
			AssassinFrame.TimeSinceLastUpdate = 0;
		end
	end
end

function Assassin_showCombo(numberCP)
	ComboBar:SetValue(numberCP);
	ComboText:SetText(numberCP .. "/5");
end

function Assassin_doSnD()
	name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitBuff("player", "Slice and Dice");
	if not name then
		SliceText:SetText("0");
		SliceBar:SetValue(0);
		return;
	end
	theBuffTime = string.format("%.1f", expirationTime - GetTime());
	SliceText:SetText(theBuffTime);
	SliceBar:SetMinMaxValues(0, duration);
	SliceBar:SetValue(theBuffTime);
end
function Assassin_doEnv()
	name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitBuff("player", "Envenom");
	if not name then
		EnvBar:SetValue(0);
		return;
	end
	theBuffTime = string.format("%.1f", expirationTime - GetTime());
	EnvBar:SetMinMaxValues(0, duration);
	EnvBar:SetValue(theBuffTime);
end
function Assassin_doNrg()
	currentEnergy = UnitMana('player')
	EnergyText:SetText(currentEnergy .. "/" .. UnitManaMax('player'));
	EnergyBar:SetMinMaxValues(0, UnitManaMax('player'));
	EnergyBar:SetValue(currentEnergy);
end

function Assassin_doRup()
	name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitDebuff("target", "Rupture");
	if not name then
		RuptureText:SetText("0");
		RuptureBar:SetValue(0);
		return;
	end
	if isMine=='player' then
		theBuffTime = string.format("%.1f", expirationTime - GetTime());
		RuptureText:SetText(theBuffTime);
		RuptureBar:SetMinMaxValues(0, duration);
		RuptureBar:SetValue(theBuffTime);
	end
end
function Assassin_OnDragStart()
	 AssassinFrame:StartMoving();
end

function Assassin_OnDragStop()
	AssassinFrame:StopMovingOrSizing()
end